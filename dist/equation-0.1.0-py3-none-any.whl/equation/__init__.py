from .equation import eq

__all__ = ["eq"]
